#include "Class_file.h"
/*
class Card
*/
string Card::cardtype = "Card";
int Card::card_all_number = 0;      //静态变量 记录所有所生成卡的总数

Card::Card(){}//无参构造

Card::Card(const string un,int cnt) //有参构造
{
    is_on_car = 0;
    username = un;
    this->cnt = cnt;
    card_all_number++;
    cardnumber = "XD2018" + To_string(card_all_number); //生成 如"XD201800001"的卡号
}
Card::~Card(){} //析构

void Card::Show_information()const//显示卡的信息
{
    string a = Return_cardnumber();
    string b = Return_username();
    std::cout<< "Name: " << b<< std::endl;
    std::cout<<"CardNumber: "<< a<< std::endl;
    std::cout<<"You have already taken the bus "<<cnt<<" times!"<<endl;
    std::cout << "Is on car: " << is_on_car << endl;
}
void Card::Get_on(){Is_On();} //上车的函数

void Card::Next_Card(Card * next_card) //更新next_card指针
{
    this->next_card = next_card;
}
Card * Card::Return_Next_Card() const //返回next_card指针的值
{
    return next_card;
}
/*
class TeacherCard
*/
string TeacherCard::cardtype = "TeacherCard"; //静态变量卡的类型

TeacherCard::TeacherCard(const string un,int cnt) : Card(un,cnt){}//构造函数


/*
class StudentCard
*/
string StudentCard::cardtype = "StudentCard";//静态变量卡的类型
StudentCard::StudentCard(const string un,const double ds,int cnt) : Card(un,cnt)//构造
{
    Deposits = ds;               //余额
}
StudentCard::~StudentCard(){} //析构

void StudentCard::Show_information()const //显示信息
{
    Card::Show_information();
    std::cout<< "Deposits: " << Deposits <<std::endl;
}
void StudentCard::Get_on() //上车的动作
{
    if(Deposits < 2)cout<<"Sorry your balance is not enough!!!"<<endl; //判断余额是否足够
    else
    {
        Is_On();
        cnt_increase();
        Deposits -= 2.0;
        if(Deposits < 4)
        {
            Show_information();
            cout<<"Please recharge in time !!!"<< endl;
        }
        else Show_information();
    }

}
/*
class LimitCard
*/
string LimitCard::cardtype = "LimitCard";//静态变量卡的类型
LimitCard::LimitCard(const string un,const double ds,int cnt) : StudentCard(un,ds,cnt){}//构造函数
void LimitCard::Get_on()
{
    int cnt = Return_cnt();
    if(cnt >= 20) //判断是否还在免费范围里
    {
        StudentCard::Get_on();

    }
    else
    {
        Is_On();
        cnt_increase();
        Show_information();
    }
}

/*
普通函数
*/
