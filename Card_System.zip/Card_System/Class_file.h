#ifndef _CLASS_FILE_H_
#define _CLASS_FILE_H_

#include <string>
#include <iostream>
#include "fun_file.h"

using std::string;
using std::cout;
using std::cin;
using std::endl;

class File_Control;
class Card                                                      //基类 Card
{
    friend File_Control;                                        //友元
private:
    int is_on_car;                                              //是否在车上 1在车上
    string username;
    string cardnumber;
    static int card_all_number;                                 //总卡数
    static string cardtype;
    int cnt;                                                    //乘车次数
    Card* next_card;                                                //指向下一个Card的指针
    Card* include_card;                                           //提供给车的链表去访问卡链表的接口
public:
    explicit Card();
    explicit Card(const string un,int cnt = 0);                                            //构造函数 输入持卡者人名
    virtual ~Card();

    virtual void Get_on();                                  //上车扣钱
    virtual void Get_down(){Is_Down();}
    void Is_On(void){cout << "START"<< endl;is_on_car = 1;}
    void Is_Down(void){is_on_car = 0;}
    int Return_Is_On(void){return is_on_car;}

    virtual void Show_information()const;                       //显示信息
    string Return_username()const {return username;}    //返回用户名
    string Return_cardnumber()const{return cardnumber;}//返回卡号
    int Return_cnt()const {return cnt;}                       //返回乘车次数
    void cnt_increase(){cnt++;}                                 //乘车次数增加一次
    void Next_Card(Card * next_card);
    Card * Return_Next_Card()const;
    void Set_Include_Card(Card*q){include_card = q;}
    Card * Return_Include_Card(void){return include_card;}
    virtual string Return_cardtype(void){return cardtype;}
    virtual double Return_Deposits(void)const{return 0;}



};

class TeacherCard : public Card                                        //教师卡
{
private:
    static string cardtype;
public:
    explicit TeacherCard(const string  un,int cnt = 0);                                    //构造函数 输入用户名
    void Get_on(){cnt_increase();Is_On();Show_information();}           //乘车 乘车次数加一 显示基本信息
    void Get_down(void){Card::Get_down();}
    void Show_information()const {Card::Show_information();}    //显示基本信息
    string Return_cardtype(void){return cardtype;}


};

class StudentCard : public Card                                        //学生卡
{
private:
    double Deposits;                                            //余额
    static string cardtype;
public:
    explicit StudentCard(const string un,const double ds = 30,int cnt = 0);                      //构造函数 输入用户名 以及存款
    virtual ~StudentCard();                                     //虚析构函数
    double Return_Deposits()const{return Deposits;}             //返回余额
    virtual void Get_on();                                      //乘车 乘车次数加一 余额减二元显示基本信息
    virtual void Get_down(){Card::Get_down();}
    void Show_information()const;                               //显示基本信息
    void cnt_increase(){Card::cnt_increase();}                  //乘车次数加一
    string Return_cardtype(void){return cardtype;}
};
class LimitCard : public StudentCard                                   //限制卡
{
private:
    static string cardtype;
public:
    LimitCard(const string un,const double ds,int cnt);                                       //构造函数 输入用户名 以及存款
    void Get_on();                                                      //前20次乘车免费 超过二十次每次扣两元
    void Get_down(){StudentCard::Get_down();}
    string Return_cardtype(void){return cardtype;}
};


#endif // CLASS_FILE_H
